
export const TUGAS_DATA = [
    { task: 'Server Migration Alpha', deadline: '2023-12-01', priority: 'High', status: 'Pending' },
    { task: 'Database Optimization', deadline: '2023-12-05', priority: 'Medium', status: 'Done' },
    { task: 'Script Validation v2', deadline: '2023-12-10', priority: 'Low', status: 'Pending' },
    { task: 'UI Theme Refinement', deadline: '2023-12-15', priority: 'Medium', status: 'Done' }
];
