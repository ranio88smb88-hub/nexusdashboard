
export const PASARAN_DATA = [
    { name: 'SINGAPORE', close: '17:30', result: '17:45', days: 'Sen, Rab, Kam, Sab, Min' },
    { name: 'HONGKONG', close: '22:30', result: '23:00', days: 'Every Day' },
    { name: 'SYDNEY', close: '13:30', result: '14:00', days: 'Every Day' },
    { name: 'MACAU', close: '13:00', result: '13:15', days: 'Every Day' },
    { name: 'TOKYO', close: '19:00', result: '19:30', days: 'Every Day' }
];
