
export const REPORTAN_DATA = [
    { id: 'NX-001', date: '2023-11-20', category: 'Operational', value: 'Rp 1.200.000' },
    { id: 'NX-002', date: '2023-11-21', category: 'Hardware', value: 'Rp 4.500.000' },
    { id: 'NX-003', date: '2023-11-22', category: 'Software', value: 'Rp 800.000' }
];
